package com.infyintern.scim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScimApplicationTests {

	@Test
	void contextLoads() {
	}

}
